﻿# TurnosApp

Aplicación de consola en **C# (.NET)** para gestionar turnos de enfermeras.  
Se usan conceptos de **POO (abstracción, herencia, polimorfismo, encapsulamiento)** y persistencia con **JSON**.  

---

## 📌 Requisitos
- Visual Studio (o VS Code) con soporte para C#  
- .NET 6 o superior  

---

## ⚙️ Cómo ejecutar el programa
1. Abrir la solución `TurnosApp.sln` en Visual Studio.  
2. Seleccionar el proyecto **TurnosApp** como *Startup Project*.  
3. Ejecutar con **Ctrl + F5** o botón ▶️.  

En consola verás este menú:  

Crear enfermera

Asignar turno

Listar enfermeras

Salir


Los datos quedan guardados en un archivo `enfermeras.json`.

---

## 🧪 Cómo ejecutar las pruebas

El proyecto incluye un segundo proyecto llamado **TurnosApp.Tests**, con pruebas unitarias en **xUnit**.  

### En Visual Studio
1. Abrir el panel **Test Explorer** (menú `Test > Test Explorer`).  
2. Hacer clic en **Run All Tests**.  
3. Verás los resultados (verde = pasó, rojo = falló).  

### En la terminal
Dentro de la carpeta raíz de la solución ejecutar:  

```bash
dotnet test

✅ Funcionalidades probadas

Creación de enfermera y almacenamiento de datos.

Asignación de turno de día o de noche.

Validación para que una enfermera no tenga dos turnos el mismo día.

Conteo de turnos asignados.

Polimorfismo mediante la interfaz IAsignadorTurnos.

Todos los tests pasan correctamente en Visual Studio:

5 Passed, 0 Failed, 0 Skipped

