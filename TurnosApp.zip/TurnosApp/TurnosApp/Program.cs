﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace TurnosApp
{
    // Abstracción + Herencia
    public abstract class Turno
    {
        public DateTime Inicio { get; set; }
        public DateTime Fin { get; set; }

        public Turno() { } // Necesario para JSON

        public Turno(DateTime inicio, DateTime fin)
        {
            Inicio = inicio;
            Fin = fin;
        }
    }

    public class TurnoDia : Turno
    {
        public TurnoDia() { } // Para JSON
        public TurnoDia(DateTime fecha) : base(
            new DateTime(fecha.Year, fecha.Month, fecha.Day, 7, 0, 0),
            new DateTime(fecha.Year, fecha.Month, fecha.Day, 19, 0, 0))
        { }
    }

    public class TurnoNoche : Turno
    {
        public TurnoNoche() { } // Para JSON
        public TurnoNoche(DateTime fecha) : base(
            new DateTime(fecha.Year, fecha.Month, fecha.Day, 19, 0, 0),
            new DateTime(fecha.Year, fecha.Month, fecha.Day, 7, 0, 0).AddDays(1))
        { }
    }

    // Encapsulamiento
    public class Enfermera
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public List<Turno> Turnos { get; private set; } = new();

        public Enfermera() { } // Para JSON

        public Enfermera(string id, string nombre)
        {
            Id = id;
            Nombre = nombre;
        }

        public void AsignarTurno(Turno t)
        {
            // Validación: no permitir más de un turno en el mismo día
            foreach (var turno in Turnos)
            {
                if (turno.Inicio.Date == t.Inicio.Date)
                {
                    Console.WriteLine("Ya tiene un turno asignado ese día.");
                    return;
                }
            }
            Turnos.Add(t);
        }

        public int CantidadTurnos() => Turnos.Count;
    }

    // Polimorfismo con interfaz
    public interface IAsignadorTurnos
    {
        void Asignar(Enfermera e, Turno t);
    }

    public class AsignadorBasico : IAsignadorTurnos
    {
        public void Asignar(Enfermera e, Turno t) => e.AsignarTurno(t);
    }

    public class Program
    {
        static string filePath = "enfermeras.json";

        public static void Main()
        {
            var enfermeras = CargarDatos();
            IAsignadorTurnos asignador = new AsignadorBasico();

            while (true)
            {
                Console.WriteLine("\n1) Crear enfermera  2) Asignar turno  3) Listar  0) Salir");
                var op = Console.ReadLine();
                if (op == "0")
                {
                    GuardarDatos(enfermeras);
                    break;
                }

                switch (op)
                {
                    case "1":
                        Console.Write("Id: "); var id = Console.ReadLine()!;
                        Console.Write("Nombre: "); var nom = Console.ReadLine()!;
                        enfermeras[id] = new Enfermera(id, nom);
                        Console.WriteLine("Enfermera creada");
                        break;

                    case "2":
                        Console.Write("Id enfermera: "); var idE = Console.ReadLine()!;
                        if (!enfermeras.ContainsKey(idE)) { Console.WriteLine("No existe"); break; }
                        Console.Write("Fecha (yyyy-MM-dd): ");
                        var fecha = DateTime.Parse(Console.ReadLine()!);
                        Console.Write("Tipo (D/N): ");
                        var tipo = Console.ReadLine()!;
                        Turno t = (tipo.ToUpper() == "N") ? new TurnoNoche(fecha) : new TurnoDia(fecha);
                        asignador.Asignar(enfermeras[idE], t);
                        break;

                    case "3":
                        foreach (var e in enfermeras.Values)
                        {
                            Console.WriteLine($"\n[{e.Id}] {e.Nombre} - Total de turnos: {e.CantidadTurnos()}");
                            foreach (var turno in e.Turnos)
                            {
                                string tipoTurno = (turno is TurnoNoche) ? "Noche" : "Día";
                                Console.WriteLine($"   - {tipoTurno} | Fecha: {turno.Inicio:yyyy-MM-dd}");
                            }
                        }
                        break;
                }
            }
        }

        public static Dictionary<string, Enfermera> CargarDatos()
        {
            if (!File.Exists(filePath)) return new Dictionary<string, Enfermera>();

            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<Dictionary<string, Enfermera>>(json, options) ?? new();
        }

        public static void GuardarDatos(Dictionary<string, Enfermera> enfermeras)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(enfermeras, options);
            File.WriteAllText(filePath, json);
            Console.WriteLine("Datos guardados en enfermeras.json");
        }
    }
}
