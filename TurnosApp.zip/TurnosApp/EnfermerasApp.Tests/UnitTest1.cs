﻿using System;
using Xunit;
using TurnosApp; // 👈 Importa tu proyecto principal

namespace TurnosApp.Tests
{
    public class EnfermeraTests
    {
        [Fact]
        public void Enfermera_CreacionCorrecta()
        {
            // Arrange & Act
            var e = new Enfermera("E1", "Ana");

            // Assert
            Assert.Equal("E1", e.Id);
            Assert.Equal("Ana", e.Nombre);
            Assert.Empty(e.Turnos);
        }

        [Fact]
        public void AsignarTurnoDia_AgregaCorrectamente()
        {
            var e = new Enfermera("E1", "Ana");
            var turno = new TurnoDia(DateTime.Parse("2025-09-07"));

            e.AsignarTurno(turno);

            Assert.Single(e.Turnos);
            Assert.Equal(turno.Inicio, e.Turnos[0].Inicio);
        }

        [Fact]
        public void AsignarDosTurnosMismoDia_NoSeAgregan()
        {
            var e = new Enfermera("E1", "Ana");
            var fecha = DateTime.Parse("2025-09-07");

            e.AsignarTurno(new TurnoDia(fecha));
            e.AsignarTurno(new TurnoNoche(fecha)); // Mismo día → debería rechazarse

            Assert.Single(e.Turnos);
        }

        [Fact]
        public void ContarTurnos_FuncionaCorrectamente()
        {
            var e = new Enfermera("E1", "Ana");
            e.AsignarTurno(new TurnoDia(DateTime.Parse("2025-09-07")));
            e.AsignarTurno(new TurnoDia(DateTime.Parse("2025-09-08")));

            Assert.Equal(2, e.CantidadTurnos());
        }

        [Fact]
        public void AsignadorBasico_UsaMetodoAsignarTurno()
        {
            var e = new Enfermera("E1", "Ana");
            var asignador = new AsignadorBasico();
            var turno = new TurnoDia(DateTime.Parse("2025-09-07"));
            asignador.Asignar(e, turno);

            Assert.Single(e.Turnos);
        }
    }
}
